﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace Fenge.Commom
{
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Hosting;
    public class GloablOpretion
    {
        public static IConfiguration Configuration { get; set; }
        public static IServiceCollection ServiceCollection { get; set; }
        public static IHostingEnvironment HostingEnvironment { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

using System.Text;

namespace Fenge.Model
{
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    [Table("ClassInfo")]
    public class ClassInfo
    {
        [Key] //, DatabaseGenerated(DatabaseGeneratedOption.Identity) 默认就是自增长的吧
        public int Cid { get; set; }
        [MaxLength(30)]
        public string Cname { get; set; }
        
        [Column("IFShow")]
        public int IFShow { get; set; } = 0;
    }
}

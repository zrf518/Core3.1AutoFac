﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fenge.BLL
{
    using Fenge.IBLL;
    using Fenge.Model;
    using Fenge.IDAL;
    public class StudentBLL : BaseBLL<Student>, IStudentBLL
    {
        public StudentBLL(IStudentDAL dal)
        {
            base.dal = dal;
        }
    }
}

﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApp
{
    using Microsoft.Extensions.DependencyInjection;
    public static class FenggeAutoInject
    {
        public static void AddAssemblyAutoInject(this IServiceCollection service, string assemblyName, ServiceLifetime serviceLifetime = ServiceLifetime.Scoped)
        {
            var assembly = RunTimeHelper.GetAssemblyByName(assemblyName);
            var types = assembly.GetTypes();
            var list = types.Where(u => u.IsClass && !u.IsAbstract && !u.IsGenericType).ToList();
            foreach (var type in list)
            {
                var interfaceList = type.GetInterfaces();
                if (interfaceList.Any())
                {
                    var inter = interfaceList.First();
                    switch (serviceLifetime)
                    {
                        case ServiceLifetime.Transient:
                            service.AddTransient(inter, type);
                            break;
                        case ServiceLifetime.Scoped:
                            service.AddScoped(inter, type);
                            break;
                        case ServiceLifetime.Singleton:
                            service.AddSingleton(inter, type);
                            break;
                    }
                //    service.AddScoped(inter, type);
                }
            }
        }
    }
}

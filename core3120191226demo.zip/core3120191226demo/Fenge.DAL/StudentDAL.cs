﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fenge.DAL
{
    using Fenge.Model;
    using Fenge.IDAL;
    public class StudentDAL : BaseDAL<Student>, IStudentDAL
    {
    }
}

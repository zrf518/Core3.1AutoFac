﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fenge.DAL
{
    using Fenge.IDAL;
    using Fenge.Model;
   public class ClassInfoDAL:BaseDAL<ClassInfo>,IClassInfoDAL
    {
    }
}

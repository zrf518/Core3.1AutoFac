﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WebApp.Models;

namespace WebApp.Controllers
{
    using Fenge.Model;
    using Fenge.IBLL;
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private IClassInfoBLL bll;
        public HomeController(ILogger<HomeController> logger, IClassInfoBLL bll)
        {
            _logger = logger;
            this.bll = bll;
        }

        public async Task<IActionResult> Index()
        {
            ClassInfo c = new ClassInfo
            {
                Cname = "火马冲中学107班",
                IFShow = 0
            };
            await bll.AddAsync(c);
            string msg = bll.SaveChanges() > 0 ? "成功" : "Faill";
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

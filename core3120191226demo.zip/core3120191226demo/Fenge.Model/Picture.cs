﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fenge.Model
{
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("Picture")]
    public class Picture
    {
        [Key]
        public int Pid { get; set; }
        [MaxLength(50)]
        public string Title { get; set; }
        [MaxLength(30)]
        public string PicNo { get; set; }
        public string Path { get; set; }
        [MaxLength(100)]
        public string Remark { get; set; }
        public int UpByUid { get; set; }
        public DateTime AddTime { get; set; }
        public int IFShow { get; set; } = 1;
    }
}

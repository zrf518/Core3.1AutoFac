﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Fenge.Model
{
    /// <summary>
    /// 公告信息
    /// </summary>
    public class Notice
    {
        [Key]
        public int Nid { get; set; }
        [MaxLength(50)]
        public string Title { get; set; }
        [MaxLength(3000)]
        public string Content { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        [MaxLength(200)]
        public string Remark { get; set; } = "如地址在火马冲镇中学，联系人是班长，联系的手机号码是110";
        public int AddUid { get; set; }
        public DateTime AddTime { get; set; }
        public int IFShow { get; set; } = 0;

    }
}

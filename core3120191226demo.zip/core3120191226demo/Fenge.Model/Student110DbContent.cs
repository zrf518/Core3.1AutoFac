﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace Fenge.Model
{
    using Fenge.Commom;
    using Microsoft.EntityFrameworkCore;
    public  class Student110DbContent:DbContext
    {
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //string sqlconstr = GloablOpretion.Configuration.GetSection("SqlConnectionString").Value;//optionsBuilder.UseMySql(sqlconstr);
            optionsBuilder.UseMySql("data source=47.107.87.32;uid=fengge;pwd=Foxconn88;database=Student110DbContent");
            base.OnConfiguring(optionsBuilder);
        }
        public DbSet<ClassInfo> ClassInfos { get; set; }
        public DbSet<Notice> Notices { get; set; }
        public DbSet<Picture> Pictures { get; set; }
        public DbSet<PostMsg> PostMsgs { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<Video> Videos { get; set; }
        public DbSet<VoteLike> VoteLikes { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fenge.DAL
{
    using Fenge.IDAL;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using Fenge.Model;
    using Microsoft.EntityFrameworkCore.ChangeTracking;
    using Microsoft.EntityFrameworkCore;
    public class BaseDAL<T> : IBaseDAL<T> where T : class, new()
    {
        Student110DbContent db = new Student110DbContent();
        public  async Task AddAsync(T entity)
        {
            await db.Set<T>().AddAsync(entity);
        }

        public void Delete(T entity)
        {
            db.Set<T>().Remove(entity);
        }

        public void Delete(Expression<Func<T, bool>> where)
        {
            IQueryable<T> qlist = db.Set<T>().Where(where);
            if (qlist!=null)
            {
                db.Set<T>().RemoveRange(qlist);
            }
        }
        public void Update(T entity,params string[] propertyNames)
        {
            EntityEntry entry= db.Entry<T>(entity);
            entry.State = EntityState.Unchanged;
            foreach (var item in propertyNames)
            {
                entry.Property(item).IsModified = true;
            }
        }

        public T GetEntityOne(Expression<Func<T,bool>>where)
        {
           return db.Set<T>().Where(where)?.FirstOrDefault();
        }

        public IQueryable<T> GetEntityList(Expression<Func<T, bool>> where)
        {
           return db.Set<T>().Where(where);
        }

        public IQueryable<T> GetEntityListOrder<orderkey>(Expression<Func<T, bool>> where, Expression<Func<T, orderkey>> orderbykey,bool asc=true)
        {
            IQueryable<T>qlist= db.Set<T>().Where(where);
            if (asc)
            {
                qlist = qlist.OrderBy(orderbykey).AsQueryable<T>();
            }
            else
            {
                    qlist = qlist.OrderByDescending(orderbykey).AsQueryable<T>();
            }
            return qlist;
        }

        public IQueryable<T> GetEntityPaginationListOrder<orderkey>(int pageSize, int pageIndex, Expression<Func<T, bool>> where, Expression<Func<T, orderkey>> orderbykey, out int rowscount,bool asc=true)
        {
            IQueryable<T> qlist = db.Set<T>().Where(where);
            if (asc)
            {
                qlist = qlist.OrderBy(orderbykey).AsQueryable<T>();
            }
            else
            {
                qlist = qlist.OrderByDescending(orderbykey).AsQueryable<T>();
            }
            rowscount = qlist.ToList().Count;
            int skipcount = (pageIndex - 1) * pageSize;
            return qlist.Skip(skipcount).Take(pageSize);
        }

        public int SaveChanges()
        {
            return db.SaveChanges();
        }


    }
}

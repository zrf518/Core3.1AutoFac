﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fenge.BLL
{
    using Fenge.Model;
    using Fenge.IBLL;
    using Fenge.IDAL;
  public  class ClassInfoBLL:BaseBLL<ClassInfo>,IClassInfoBLL
    {
        public ClassInfoBLL(IClassInfoDAL dal)
        {
            base.dal = dal;
        }
    }
}

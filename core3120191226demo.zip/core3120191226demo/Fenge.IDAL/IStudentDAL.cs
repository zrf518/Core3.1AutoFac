﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fenge.IDAL
{
    using Fenge.Model;
    public interface IStudentDAL : IBaseDAL<Student>
    {
    }
}

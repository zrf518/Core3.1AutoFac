﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fenge.IBLL
{
    using Fenge.Model;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;

    public interface IBaseBLL<T> where T : class, new()
    {
        Task AddAsync(T entity);

        void Delete(T entity);

        void Delete(Expression<Func<T, bool>> where);

        void Update(T entity, params string[] propertyNames);

        T GetEntityOne(Expression<Func<T, bool>> where);

        IQueryable<T> GetEntityList(Expression<Func<T, bool>> where);


        IQueryable<T> GetEntityListOrder<orderkey>(Expression<Func<T, bool>> where, Expression<Func<T, orderkey>> orderbykey, bool asc = true);


        IQueryable<T> GetEntityPaginationListOrder<orderkey>(int pageSize, int pageIndex, Expression<Func<T, bool>> where, Expression<Func<T, orderkey>> orderbykey, out int rowscount, bool asc = true);

        int SaveChanges();
    }
}

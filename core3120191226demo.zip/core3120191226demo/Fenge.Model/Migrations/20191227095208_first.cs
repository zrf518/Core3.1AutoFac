﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Fenge.Model.Migrations
{
    public partial class first : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ClassInfo",
                columns: table => new
                {
                    Cid = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Cname = table.Column<string>(maxLength: 30, nullable: true),
                    IFShow = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ClassInfo", x => x.Cid);
                });

            migrationBuilder.CreateTable(
                name: "Notices",
                columns: table => new
                {
                    Nid = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Title = table.Column<string>(maxLength: 50, nullable: true),
                    Content = table.Column<string>(maxLength: 3000, nullable: true),
                    StartTime = table.Column<DateTime>(nullable: false),
                    EndTime = table.Column<DateTime>(nullable: false),
                    Remark = table.Column<string>(maxLength: 200, nullable: true),
                    AddUid = table.Column<int>(nullable: false),
                    AddTime = table.Column<DateTime>(nullable: false),
                    IFShow = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Notices", x => x.Nid);
                });

            migrationBuilder.CreateTable(
                name: "Picture",
                columns: table => new
                {
                    Pid = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Title = table.Column<string>(maxLength: 50, nullable: true),
                    PicNo = table.Column<string>(maxLength: 30, nullable: true),
                    Path = table.Column<string>(nullable: true),
                    Remark = table.Column<string>(maxLength: 100, nullable: true),
                    UpByUid = table.Column<int>(nullable: false),
                    AddTime = table.Column<DateTime>(nullable: false),
                    IFShow = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Picture", x => x.Pid);
                });

            migrationBuilder.CreateTable(
                name: "PostMsgs",
                columns: table => new
                {
                    PostID = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    StuID = table.Column<int>(nullable: false),
                    PictureVideoId = table.Column<int>(nullable: false),
                    PVType = table.Column<int>(nullable: false),
                    SayMsg = table.Column<string>(nullable: false),
                    AddTime = table.Column<DateTime>(nullable: false),
                    IFShow = table.Column<int>(nullable: false),
                    IFCheck = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PostMsgs", x => x.PostID);
                });

            migrationBuilder.CreateTable(
                name: "Videos",
                columns: table => new
                {
                    Vid = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    UpSid = table.Column<int>(nullable: false),
                    Title = table.Column<string>(maxLength: 50, nullable: true),
                    PicNo = table.Column<string>(maxLength: 30, nullable: true),
                    Remark = table.Column<string>(maxLength: 100, nullable: true),
                    Path = table.Column<string>(nullable: true),
                    AddTime = table.Column<DateTime>(nullable: false),
                    IFShow = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Videos", x => x.Vid);
                });

            migrationBuilder.CreateTable(
                name: "VoteLikes",
                columns: table => new
                {
                    VoteID = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    StuID = table.Column<int>(nullable: false),
                    PictureVideoID = table.Column<int>(nullable: false),
                    YesOrNo = table.Column<int>(nullable: false),
                    AddTime = table.Column<DateTime>(nullable: false),
                    CustomerPCPhoneType = table.Column<string>(nullable: true),
                    IFShow = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VoteLikes", x => x.VoteID);
                });

            migrationBuilder.CreateTable(
                name: "Students",
                columns: table => new
                {
                    Sid = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Sname = table.Column<string>(nullable: false),
                    Cid = table.Column<int>(nullable: false),
                    ClassInfoCid = table.Column<int>(nullable: true),
                    Sex = table.Column<int>(nullable: false),
                    Addr = table.Column<string>(nullable: true),
                    WxNo = table.Column<string>(nullable: true),
                    QQ = table.Column<string>(nullable: true),
                    Phone = table.Column<string>(nullable: false),
                    Tel = table.Column<string>(nullable: true),
                    Email = table.Column<string>(nullable: true),
                    HeadImg = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Students", x => x.Sid);
                    table.ForeignKey(
                        name: "FK_Students_ClassInfo_ClassInfoCid",
                        column: x => x.ClassInfoCid,
                        principalTable: "ClassInfo",
                        principalColumn: "Cid",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Students_ClassInfoCid",
                table: "Students",
                column: "ClassInfoCid");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Notices");

            migrationBuilder.DropTable(
                name: "Picture");

            migrationBuilder.DropTable(
                name: "PostMsgs");

            migrationBuilder.DropTable(
                name: "Students");

            migrationBuilder.DropTable(
                name: "Videos");

            migrationBuilder.DropTable(
                name: "VoteLikes");

            migrationBuilder.DropTable(
                name: "ClassInfo");
        }
    }
}

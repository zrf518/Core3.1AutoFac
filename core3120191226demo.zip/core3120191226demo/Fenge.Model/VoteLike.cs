﻿using System;
using System.Collections.Generic;

using System.Text;

namespace Fenge.Model
{
    using System.ComponentModel.DataAnnotations;
    public class VoteLike
    {
        [Key]
        public int VoteID { get; set; }
        
        [Required]
        public int StuID { get; set; }

        [Required]
        public int PictureVideoID { get; set; }

        public int YesOrNo { get; set; }

        public DateTime AddTime { get; set; }

        public string CustomerPCPhoneType { get; set; }
        public int IFShow { get; set; } = 0;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fenge.Model
{
    using System.ComponentModel.DataAnnotations;
    public class Video
    {
        [Key]
        public int Vid { get; set; }
        public int UpSid { get; set; }
        [MaxLength(50)]
        public string Title { get; set; }
        [MaxLength(30)]
        public string PicNo { get; set; }
        [MaxLength(100)]
        public string Remark { get; set; }
        public string Path { get; set; }
        public DateTime AddTime { get; set; }
        public int IFShow { get; set; } = 0;
    }
}

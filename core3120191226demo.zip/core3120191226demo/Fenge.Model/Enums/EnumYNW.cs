﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fenge.Model
{
    using System.ComponentModel.DataAnnotations;
    public enum EnumYNW
    {
        [Display(Name = "非常喜欢")]
        Yes = 0,

        [Display(Name = "一般喜欢")]
        Nomal = 2,

        [Display(Name = "感觉一般")]
        No = 1
    }
}

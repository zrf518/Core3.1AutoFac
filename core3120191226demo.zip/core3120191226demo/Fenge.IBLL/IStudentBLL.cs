﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fenge.IBLL
{
    using Fenge.Model;
    public interface IStudentBLL:IBaseBLL<Student>
    {
    }
}

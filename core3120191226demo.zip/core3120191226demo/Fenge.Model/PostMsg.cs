﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fenge.Model
{
    using System.ComponentModel.DataAnnotations;
    public  class PostMsg
    {
        [Key]
        public int PostID { get; set; }
        [Required]
        public int StuID { get; set; }
        [Required]
        public int PictureVideoId { get; set; }
        [Required]
        public int PVType { get; set; }
        [Required]
        public string  SayMsg { get; set; }
        public DateTime AddTime { get; set; }
        public int IFShow { get; set; } = 0;
        public int IFCheck { get; set; } = 0;
    }
}

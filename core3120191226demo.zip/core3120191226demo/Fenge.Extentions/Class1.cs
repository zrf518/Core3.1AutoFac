﻿using System;

namespace Fenge.Extentions
{
    public class Class1
    {
    }
}

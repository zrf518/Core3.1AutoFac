﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fenge.Model
{
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    public class Student
    {
        [Key]
        public int Sid { get; set; }
        [Required]
        public string Sname { get; set; }

        [Required, ForeignKey("ClassInfo.Cid")]
        public int Cid { get; set; }
        public virtual ClassInfo ClassInfo { get; set; }
        public int Sex { get; set; }
        public string Addr { get; set; }
        public string WxNo { get; set; }
        public string QQ { get; set; }
        [Required]
        public string Phone { get; set; }
        public string Tel { get; set; }
        public string Email { get; set; }
        public string HeadImg { get; set; }
    }
}

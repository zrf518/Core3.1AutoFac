﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fenge.BLL
{
    using Fenge.IBLL;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using Fenge.IDAL;
    public class BaseBLL<T> : IBaseBLL<T> where T : class, new()
    {
        public IBaseDAL<T> dal;  //-----------待处理

        public async Task AddAsync(T entity)
        {
            await dal.AddAsync(entity);
        }

        public void Delete(T entity)
        {
            dal.Delete(entity);
        }

        public void Delete(Expression<Func<T, bool>> where)
        {
            dal.Delete(where);
        }

        public IQueryable<T> GetEntityList(Expression<Func<T, bool>> where)
        {
            return dal.GetEntityList(where);
        }

        public IQueryable<T> GetEntityListOrder<orderkey>(Expression<Func<T, bool>> where, Expression<Func<T, orderkey>> orderbykey, bool asc = true)
        {
            return dal.GetEntityListOrder<orderkey>(where, orderbykey, asc);
        }

        public T GetEntityOne(Expression<Func<T, bool>> where)
        {
            return dal.GetEntityOne(where);
        }

        public IQueryable<T> GetEntityPaginationListOrder<orderkey>(int pageSize, int pageIndex, Expression<Func<T, bool>> where, Expression<Func<T, orderkey>> orderbykey, out int rowscount, bool asc = true)
        {
            return dal.GetEntityPaginationListOrder<orderkey>(pageSize, pageIndex, where, orderbykey, out rowscount, asc);
        }

        public int SaveChanges()
        {
            return dal.SaveChanges();
        }

        public void Update(T entity, params string[] propertyNames)
        {
            dal.Update(entity, propertyNames);
        }
    }
}
